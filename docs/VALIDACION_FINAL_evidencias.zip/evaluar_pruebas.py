from pathlib import Path
import struct,json
OUT=Path(__file__).resolve().parent
cases=json.loads((OUT/'casos.json').read_text('utf8'))
meta=json.loads((OUT/'procedencia.json').read_text('utf8'))
raw=(OUT/'RESULT.BIN').read_bytes()
size=2+0x480+4000
assert len(raw)==len(cases)*size,(len(raw),len(cases)*size)
results=[]
for i,c in enumerate(cases):
    rec=raw[i*size:(i+1)*size]
    assert struct.unpack_from('<H',rec)[0]==c['id']
    data=rec[2:2+0x480];video=rec[2+0x480:]
    state={}
    for name in ['paleta_x','pelota_x','pelota_y','pelota_dx','pelota_dy','vidas','puntos','bloques_restantes','high_score','juego_activo']:
        off=meta['symbols'][name.upper()]['offset']
        state[name]=int.from_bytes(data[off:off+(2 if name in ['puntos','bloques_restantes','high_score'] else 1)],'little')
    state['bloques_activos']=sum(x!=0 for x in data[10:170])
    screen='\n'.join(bytes(video[r*160:r*160+160:2]).decode('cp437') for r in range(25))
    errors=[f'{k}: esperado {v}, obtenido {state[k]}' for k,v in c['expected'].items() if state[k]!=v]
    errors += [f'Texto ausente: {text!r}' for text in c['screen'] if text not in screen]
    (OUT/f'pantalla-{c["id"]:02}.txt').write_text(screen,encoding='utf8')
    results.append({**c,'obtained':state,'errors':errors,'passed':not errors})
(OUT/'resultados.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf8')
for r in results:
    print(f'{r["id"]:02} {"OK" if r["passed"] else "FALLO"} {r["name"]}: '+('; '.join(r['errors']) if r['errors'] else str(r['obtained'])))
print('TOTAL',len(results),'OK',sum(r['passed'] for r in results),'FALLOS',sum(not r['passed'] for r in results))
