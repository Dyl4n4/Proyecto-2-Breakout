from pathlib import Path
import json
p=Path(__file__).resolve().parent
m=json.loads((p/'procedencia.json').read_text('utf8'))
lines=['format MZ','entry main:start','stack 100h','segment datos use16',
       f"file 'BASE.EXE':{m['original_data_offset']},1152",
       "nombre db 'MEMORIA.BIN',0",'handle dw 0','indice dw 0',
       'fallos dd 0','validos dw 0','primero dw 0ffffh','sp_antes dw 0','esperado db 1152 dup(0)',
       'segment main use16',f"file 'BASE.EXE':{m['original_code_offset']},{m['original_code_length']}"]
for n,s in m['symbols'].items():
    if s['kind']!='SEGMENT': lines.append(f'{n} equ {s["offset"]}')
lines+=['start:','mov ax,datos','mov ds,ax','push ds','pop es','cld',
 'siguiente:','call REINICIAR_JUEGO','mov ax,[indice]','mov [PELOTA_X],al','mov [PELOTA_Y],ah',
 'mov byte [FISICA_Y_PREVIA],1','mov byte [PELOTA_DX],1','mov byte [PELOTA_DY],1',
 'xor si,si','mov di,esperado','mov cx,1152','rep movsb',
 # Oracle based on the visible rectangles: 8 rows, cells of 4 with a gap at remainder 3.
 'mov ax,[indice]','cmp ah,2','jb no_impacto','cmp ah,9','ja no_impacto',
 'cmp al,2','jb no_impacto','cmp al,79','ja no_impacto','sub al,2',
 'mov bl,al','and bl,3','cmp bl,3','je no_impacto',
 'xor ah,ah','mov bl,4','div bl','xor ah,ah','mov bx,ax',
 'mov ax,[indice]','mov al,ah','xor ah,ah','sub al,2','mov dl,20','mul dl','add bx,ax',
 'mov byte [esperado+BLOQUES+bx],0',
 'mov word [esperado+BLOQUES_RESTANTES],159','mov word [esperado+PUNTOS],10',
 'mov byte [esperado+PELOTA_DY],255','inc word [validos]',
 'no_impacto:','mov [sp_antes],sp','call VERIFICAR_COLISION_BLOQUES',
 'cmp sp,[sp_antes]','jne fallo','xor si,si','mov di,esperado','mov cx,1152','repe cmpsb','je avanzar',
 'fallo:','cmp word [fallos],0','jne contar','cmp word [fallos+2],0','jne contar',
 'mov ax,[indice]','mov [primero],ax',
 'contar:','add word [fallos],1','adc word [fallos+2],0',
 'avanzar:','inc word [indice]','jnz siguiente',
 'mov dx,nombre','xor cx,cx','mov ah,3ch','int 21h','jc error_salida','mov bx,ax',
 'mov dx,fallos','mov cx,8','mov ah,40h','int 21h','mov ah,3eh','int 21h',
 'mov ax,4c00h','int 21h','error_salida:','mov ax,4c01h','int 21h']
(p/'MEMORIA.ASM').write_text('\n'.join(lines)+'\n',encoding='ascii')
