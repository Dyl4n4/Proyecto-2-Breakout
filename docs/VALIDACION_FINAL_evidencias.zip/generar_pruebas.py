from pathlib import Path
import re, json, hashlib, struct, shutil

ROOT=Path(r'C:\Users\sophie\Proyectos\Proyecto-2-Breakout')
OUT=Path(__file__).resolve().parent
source=(ROOT/'src/breakout.asm').read_bytes()
snapshot=(ROOT/'pruebas/base/BASE.exe.~asm').read_bytes()
def norm(b):
    return [x.split(';')[0].strip() for x in b.decode('cp1252').splitlines() if x.split(';')[0].strip()]
assert norm(source)==norm(snapshot), 'El ejecutable no corresponde a las instrucciones actuales'
binary=(ROOT/'pruebas/base/BASE.exe').read_bytes()
shutil.copyfile(ROOT/'pruebas/base/BASE.exe',OUT/'BASE.EXE')
syms={}
for line in (ROOT/'pruebas/base/BASE.exe.symbol').read_text('cp1252').splitlines():
    m=re.match(r'^(\w+)\s+([0-9A-F]{5})\s+(-?\d+)\s+(\w+)\s+(\S+)',line)
    if m: syms[m[1]]={'offset':int(m[2],16),'kind':m[4],'segment':m[5]}
header=struct.unpack_from('<14H',binary)
hb=header[4]*16
ds=syms['DATA']['offset']*16
cs=header[11]*16
assert binary[hb+cs]==0xB8
# Validate the bytes in emu8086's listing against the existing executable.
listing=(ROOT/'pruebas/base/BASE.exe.list').read_text('cp1252')
matched=0
for line in listing.splitlines():
    m=re.match(r'^\[\s*\d+\]\s+([0-9A-F]{4}):\s+((?:[0-9A-F]{2}\s+)+)',line)
    if not m: continue
    loc=int(m[1],16); raw=bytes.fromhex(m[2]); pos=hb+loc
    assert binary[pos:pos+len(raw)]==raw,(loc,raw.hex(),binary[pos:pos+len(raw)].hex())
    matched+=len(raw)
meta={'source_sha256':hashlib.sha256(source).hexdigest(),'binary_sha256':hashlib.sha256(binary).hexdigest(),
      'snapshot_instruction_data_match':True,'listing_bytes_checked':matched,'symbols':syms,
      'original_code_offset':hb+cs,'original_data_offset':hb+ds,'original_code_length':len(binary)-hb-cs}
(OUT/'procedencia.json').write_text(json.dumps(meta,indent=2),encoding='utf8')
code=['format MZ','entry main:start','stack 100h','segment datos use16',
      f"file 'BASE.EXE':{hb+ds},{cs-ds}","nombre db 'RESULT.BIN',0",'handle dw 0','caso dw 0',
      'segment main use16',f"file 'BASE.EXE':{hb+cs},{len(binary)-hb-cs}"]
for name,s in syms.items():
    if s['kind']!='SEGMENT': code.append(f"{name} equ {s['offset']}")
code+=['start:','mov ax,datos','mov ds,ax','mov dx,nombre','xor cx,cx','mov ah,3ch','int 21h',
       'jnc abrir_ok','mov ax,4c01h','int 21h','abrir_ok:','mov [handle],ax']
# Only temporary copies: convert loop boundaries into returns for isolated calls.
for name in ['NO_TECLA','ESPERAR_ENTER','MOSTRAR_MENU']:
    code.append(f'mov byte [cs:{syms[name]["offset"]}],0c3h')
cases=[]
def case(name, body, expected=None, screen=None, reset=True):
    i=len(cases)+1
    code.append(f'; Caso {i}: {name}')
    if reset: code.extend(['call REINICIAR_JUEGO','call LIMPIAR_PANTALLA'])
    code.extend(body)
    code.extend([f'mov word [caso],{i}','call guardar'])
    cases.append({'id':i,'name':name,'expected':expected or {},'screen':screen or []})
def setv(**kwargs):
    return [f'mov {"word" if syms[k.upper()]["offset"] in (170,172,175) else "byte"} [{k.upper()}],{v}' for k,v in kwargs.items()]
case('E01 reinicio',['call DIBUJAR_CAMPO_INICIAL','call MOSTRAR_INFO'],{'vidas':3,'puntos':0,'bloques_restantes':160,'bloques_activos':160,'juego_activo':1},['Puntos: 0','B:160','V:3'])
for name,x,y,dx,dy,exp in [
 ('F01 pared izquierda',1,15,255,1,{'pelota_x':1,'pelota_dx':1}),
 ('F02 pared derecha',79,15,1,1,{'pelota_x':79,'pelota_dx':255}),
 ('F03 techo',40,1,1,255,{'pelota_y':1,'pelota_dy':1}),
 ('F04 paleta mitad izquierda',36,22,1,1,{'pelota_x':37,'pelota_y':22,'pelota_dx':255,'pelota_dy':255,'vidas':3}),
 ('F05 paleta mitad derecha',43,22,1,1,{'pelota_x':44,'pelota_y':22,'pelota_dx':1,'pelota_dy':255,'vidas':3}),
 ('F06 no rebotar subiendo',36,24,1,255,{'pelota_y':23,'pelota_dy':255}),
 ('E05 caida fuera paleta',20,23,1,1,{'vidas':2,'pelota_x':40,'pelota_y':18,'pelota_dy':255}),
 ('F07 borde izquierdo paleta',34,22,1,1,{'pelota_y':22,'pelota_dx':255}),
 ('F08 borde derecho paleta',45,22,1,1,{'pelota_y':22,'pelota_dx':1}),
 ('F09 fuera borde derecho',46,22,1,1,{'pelota_y':23,'pelota_dy':1})]:
    case(name,setv(pelota_x=x,pelota_y=y,pelota_dx=dx,pelota_dy=dy)+['call MOVER_PELOTA'],exp)
case('E06 conservar puntos y bloques',setv(pelota_x=2,pelota_y=2,fisica_x_previa=2,fisica_y_previa=1)+['call VERIFICAR_COLISION_BLOQUES']+setv(pelota_x=20,pelota_y=23,pelota_dx=1,pelota_dy=1)+['call MOVER_PELOTA'],{'vidas':2,'puntos':10,'bloques_restantes':159,'bloques_activos':159})
case('E07 tres perdidas',['call PERDER_VIDA']*3+['call FIN_JUEGO'],{'vidas':0,'juego_activo':0},['*** PERDISTE ***'])
for x in [2,4,5,6,77,78,79,80,0,255]:
    valid=x in [2,4,6,78,79]
    case(f'F10 colision x={x}',setv(pelota_x=x,pelota_y=2,fisica_x_previa=x,fisica_y_previa=1)+['call VERIFICAR_COLISION_BLOQUES'],{'puntos':10 if valid else 0,'bloques_restantes':159 if valid else 160,'bloques_activos':159 if valid else 160})
for y in [0,1,2,9,10,24,255]:
    valid=y in [2,9]
    case(f'F11 colision y={y}',setv(pelota_x=2,pelota_y=y,fisica_x_previa=2,fisica_y_previa=1)+['call VERIFICAR_COLISION_BLOQUES'],{'puntos':10 if valid else 0,'bloques_restantes':159 if valid else 160})
case('F12 bloque destruido no repuntua',setv(pelota_x=2,pelota_y=2,fisica_y_previa=1)+['call VERIFICAR_COLISION_BLOQUES']*2,{'puntos':10,'bloques_restantes':159,'bloques_activos':159})
case('F13 rebote lateral',setv(pelota_x=6,pelota_y=3,fisica_x_previa=5,fisica_y_previa=2,pelota_dx=1,pelota_dy=1)+['call VERIFICAR_COLISION_BLOQUES'],{'pelota_dx':255,'pelota_dy':1,'puntos':10})
case('F14 rebote vertical',setv(pelota_x=3,pelota_y=3,fisica_x_previa=2,fisica_y_previa=2,pelota_dx=1,pelota_dy=1)+['call VERIFICAR_COLISION_BLOQUES'],{'pelota_dx':1,'pelota_dy':255,'puntos':10})
body=[]
for row in range(8):
    for col in range(20):
        body+=setv(pelota_x=2+4*col,pelota_y=2+row,fisica_y_previa=1)+['call VERIFICAR_COLISION_BLOQUES']
case('F15 eliminar 160 bloques',body+['call FIN_JUEGO'],{'puntos':1600,'bloques_restantes':0,'bloques_activos':0,'juego_activo':0},['*** GANASTE ***','Puntos: 1600','Record: 1600'])
case('E08 record nuevo',setv(high_score=0,puntos=200)+['call MOSTRAR_MSG'],{'high_score':200},['Record: 200'])
case('E08 record se conserva',setv(puntos=100)+['call MOSTRAR_MSG'],{'high_score':200},['Record: 200'])
case('E08 record igual',setv(puntos=200)+['call MOSTRAR_MSG'],{'high_score':200})
case('E09 reinicio tras partida',['call REINICIAR_JUEGO','call DIBUJAR_CAMPO_INICIAL','call MOSTRAR_INFO'],{'vidas':3,'puntos':0,'bloques_restantes':160,'bloques_activos':160,'high_score':200},['Puntos: 0','B:160','V:3'])
case('I02 mover A',['call MOVER_IZQ'],{'paleta_x':33})
case('I02 mover D',['call MOVER_DER'],{'paleta_x':37})
case('I04 limite izquierdo',['call MOVER_IZQ']*40,{'paleta_x':1})
case('I04 limite derecho',['call MOVER_DER']*40,{'paleta_x':67})
for name,scan,ascii_,expected in [('A',0x1e,ord('a'),33),('D',0x20,ord('d'),37),('izquierda',0x4b,0,33),('derecha',0x4d,0,37)]:
    case(f'I03 teclado {name}',[f'mov cx,{(scan<<8)|ascii_}','mov ah,5','int 16h','call GAME_LOOP'],{'paleta_x':expected})
case('E02 E03 pausa ignora A D y reanuda',sum(([f'mov cx,{k}','mov ah,5','int 16h'] for k in [0x1970,0x1e61,0x2064,0x1970]),[])+['call GAME_LOOP'],{'paleta_x':35,'pelota_x':40,'pelota_y':18,'vidas':3,'puntos':0})
case('I06 Escape retorna al menu',['mov cx,011bh','mov ah,5','int 16h','call GAME_LOOP'],{'vidas':3,'puntos':0})
case('I05 instrucciones',['call DIBUJAR_INSTRUCCIONES'],{},['Usa A y D o las flechas','volder al menu'])
case('I01 dibujar menu',['call DIBUJAR_MENU'],{},['1. JUGAR','2. INSTRUCCIONES','3. SALIR','Selecciona 1-3 o J/I/S'])
# Check the actual decreasing counter sequence, leaving video uncleared.
case('E10 B160',['call MOSTRAR_INFO'],{},['B:160 '])
for count in [100,99,98,10,9,8,1,0]:
    case(f'E10 B{count}',setv(bloques_restantes=count)+['call MOSTRAR_INFO'],{},[f'B:{count} '],reset=False)
code+=['mov bx,[handle]','mov ah,3eh','int 21h','mov ax,4c00h','int 21h',
       'guardar:','push ax','push bx','push cx','push dx','push ds',
       'mov bx,[handle]','mov dx,caso','mov cx,2','mov ah,40h','int 21h',
       'xor dx,dx','mov cx,480h','mov ah,40h','int 21h',
       'mov ax,0b800h','mov ds,ax','xor dx,dx','mov cx,4000','mov ah,40h','int 21h',
       'pop ds','pop dx','pop cx','pop bx','pop ax','ret']
(OUT/'HARNESS.ASM').write_text('\n'.join(code)+'\n',encoding='ascii')
(OUT/'casos.json').write_text(json.dumps(cases,ensure_ascii=False,indent=2),encoding='utf8')
print(f'Generados {len(cases)} casos; {matched} bytes contrastados con listado; fuente intacto.')
